# kgt_mlst (mlst tool with kmergenetyper)

# Installation

`conda install -c genomicepidemiology kgt_mlst`

# Usage

`kgt_mlst -h`

# Database download

The following command will download the kgt_mlst database to your current working directory:

`kgt_mlst --download_db`